           package com.autobots.pages;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.dom4j.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AutoPages
{

	 public WebDriver driver;
	 //public int count =0; 
	 File htmlTemplateFile;
	String title,body,htmlString;
		
	   
	   public AutoPages(WebDriver driver)
      {

		   this.driver = driver;
	   }
	   
	   public boolean Visibility(String xPath)
		{
			try 
			{
				WebDriverWait wait = new WebDriverWait(driver,20);
			    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xPath)));
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.exit(0);
			}
			return true;
		}
	   

public void Click(String xPath)
     {  
	System.out.println(xPath);       
	if(Visibility(xPath))
	           driver.findElement(By.xpath(xPath)).click();
	 
     }

public void SendValues(String value , String xPath)
{
	if(Visibility(xPath))
	   driver.findElement(By.xpath(xPath)).sendKeys(value);
}

public void Clear(String xPath)
{
	if(Visibility(xPath))
		driver.findElement(By.xpath(xPath)).clear();
}

public void DropDown(String xPath, String value)
{
	if(Visibility(xPath))
	{
	Select City= new Select(driver.findElement(By.xpath(xPath)));
  City.selectByValue(value); 
	}
}

public void CheckBox(String xPath)
{
	if(Visibility(xPath))
	{ 
	List<WebElement> check = driver.findElements(By.xpath(xPath));
	 check.get(0).click();
	}
}

public String getXpath(Document document, String xmlXPath)
{
	
	//System.out.println(driver.findElement(By.id(document.selectSingleNode(xmlXPath).getText())).toString());
	return driver.findElement(By.xpath(document.selectSingleNode(xmlXPath).getText())).toString();

}

public String getXmlValue(Document document,String xml)
{
	return document.selectSingleNode(xml).getText();
}

public void travellerCount(String xPath,int n)
{
	
for(int i=1;i<n;i++)
      Click(xPath);

}
public String  getXmlPath(String Xml) 
{
	String s ="//goibibo/path/";
	return s.concat(Xml);
}

public String  getXmlData(String Data) 
{
	String s ="//goibibo/data/";
	return s.concat(Data);
}

public void initHtmlReport(int counter)
{
	htmlTemplateFile=new File("./Report/ReportTemplate.html");
	try
	{
		htmlString = FileUtils.readFileToString(htmlTemplateFile);
	}
	catch(IOException e)
	{
		System.out.println("Error in init html generator");
		e.printStackTrace();
	}
	
	title="Html Reports";
	body="<h1>Test Report</h1><br>"+"Total Tests Run="+counter;
	htmlString=htmlString.replace("$title",title);
	htmlString=htmlString.replace("$body",body);
	htmlString=htmlString.replace("$table","<br>Testing my logic");


	try
	{
		File htmlReport = new File("./Report/HtmlReport.html");
		FileUtils.writeStringToFile(htmlReport,htmlString);
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}

}

