package com.autobots.test;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.testng.annotations.Parameters;

public class Driver {
	WebDriver driver;
	Properties pro;
	public Driver(){
		try
		{
		File src= new File("D:/dataservlet3.0/AutoBots/Config/Forms.property");
		FileInputStream fis = new FileInputStream(src);
		pro = new Properties();
		pro.load(fis);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		String browsername = pro.getProperty("browser");
		if(browsername.equalsIgnoreCase("firefox")){
			
			driver = new FirefoxDriver();
			driver.get(pro.getProperty("URL"));
		}
		else if(browsername.equalsIgnoreCase("chrome")){
			
			String chromePath = pro.getProperty("ChromeDriver");
			System.setProperty("webdriver.chrome.driver", chromePath);
			driver= new ChromeDriver();
			driver.get(pro.getProperty("URL"));
		}
		else if(browsername.equalsIgnoreCase("IE")){
			
			String IEPath = pro.getProperty("IEDriver");
			System.setProperty("webdriver.ie.driver", IEPath);
			driver= new InternetExplorerDriver();
			driver.get(pro.getProperty("URL"));
			
		}
	}
	public WebDriver getdriver(){
		
	return driver;
	}

}
