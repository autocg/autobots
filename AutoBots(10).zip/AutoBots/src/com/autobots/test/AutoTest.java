package com.autobots.test;

import java.io.File;
import java.io.FileInputStream;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;
//import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
//import org.testng.annotations.AfterMethod;
//import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.autobots.pages.AutoPages;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class AutoTest {
	AutoPages p;
	WebDriver driver;
	int counter=0;
	long starttime,endtime;	
	ExtentReports reports;
	ExtentTest logger;
	
	
	
	@BeforeClass
	public void first(){
	Driver dr = new Driver();
	driver=dr.getdriver();
	}
	
	public void waiting1()throws InterruptedException
	{
		Thread.sleep(500);
	}
	
	@Test(priority=1)
	  public void testMethodRoundWay() throws Exception
	  {
		//p.extent("testMethodRoundWay");
		starttime=System.currentTimeMillis();
		AutoPages p = PageFactory.initElements(driver, AutoPages.class);
		//logger.log(LogStatus.INFO, "Browser Started");//start
		
	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		//logger.log(LogStatus.INFO, "application is up and running");//running
		
		
		p.Click(document.selectSingleNode(p.getXmlPath("roundtrip")).getText());
		
		waiting1();
	    p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
	    waiting1();
	    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
	    waiting1();
	    p.Click(document.selectSingleNode(p.getXmlPath("revert")).getText());
	    waiting1();
	    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
	    waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("openreturnCalendar")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("selectReturnDate")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Traveller")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Aplus")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Cplus")).getText());
		waiting1();
		p.DropDown(document.selectSingleNode(p.getXmlPath("Class")).getText(), "B");
		waiting1();
		 p.CheckBox(document.selectSingleNode(p.getXmlPath("setgo")).getText());
		 waiting1();
		 p.Click(document.selectSingleNode(p.getXmlPath("ticket1")).getText());
		 waiting1();
		 p.Click(document.selectSingleNode(p.getXmlPath("ticket2")).getText());
		 waiting1();
		 p.Click(document.selectSingleNode(p.getXmlPath("Tbook")).getText());
		 waiting1();
		   counter++;
		  // logger.log(LogStatus.PASS, "testMethodRoundWay");
		  // AutoPages.captureScreenshot("img1.jpeg");
		   AutoPages.captureScreenshot("srj.jpeg");
		 
     }
	
	@Test(priority=2)
	public void Redirect()
	{
		
		driver.get("https://www.goibibo.com/");
		//logger.log(LogStatus.INFO, "redirect test is running");
		counter++;
		//logger.log(LogStatus.PASS, "Redirect");
		 // p.captureScreenshot(driver, "Redirect");
		//AutoPages.captureScreenshot("img2.jpeg");
	}
	
	@Test(priority=3)
	 public void testMethodOneWay() throws Exception
	  {
		
		//logger.log(LogStatus.INFO, "one way testing is running");
	 p = PageFactory.initElements(driver, AutoPages.class);

	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		
	    p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
	    waiting1();
	    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
	    waiting1();
	    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
	    waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Traveller")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Aplus")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Cplus")).getText());
		waiting1();
		p.DropDown(document.selectSingleNode(p.getXmlPath("Class")).getText(), "B");
		waiting1();
		 p.CheckBox(document.selectSingleNode(p.getXmlPath("setgo")).getText());
		 waiting1();
		 p.Click(document.selectSingleNode(p.getXmlPath("Obook")).getText());
		 waiting1();
		   counter++;
		   //logger.log(LogStatus.PASS, "testMethodOneWay");
		  // AutoPages.captureScreenshot("img3.jpeg");
			
   }
	@Test(priority=4)
	public void Redirect1()
	{
		//p.extent("Redirect1");
		//logger.log(LogStatus.INFO, "redirecting again  ");
		driver.get("https://www.goibibo.com/");
		counter++;
		//logger.log(LogStatus.PASS, "Redirect1");
		//AutoPages.captureScreenshot("img4.jpeg");
		 
	}
	
	
	@Test(priority=5)
	  public void NegativeTest() throws Exception
	  {
		
		//logger.log(LogStatus.INFO, "negative test is running");
		 p = PageFactory.initElements(driver, AutoPages.class);

	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		 
		 p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
		 waiting1();
		    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
		    waiting1();
		    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
		    waiting1();
			p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
			waiting1();
			p.Click(document.selectSingleNode(p.getXmlPath("openreturnCalendar")).getText());
			waiting1();
			p.Click(document.selectSingleNode(p.getXmlPath("selectReturnDate")).getText());
			waiting1();
		
	    System.out.println("System fails when we try to book for one way trip as it automatically select to round trip");
	    counter++;
	    endtime=System.currentTimeMillis();
	  //  logger.log(LogStatus.PASS, "NegativeTest");
	  //  AutoPages.captureScreenshot("img5.jpeg");
		
	  }
@AfterClass
	public void Last() throws InterruptedException
	{
		p.initHtmlReport(counter, starttime, endtime);
		waiting1();
		p.endTest();
		driver.quit();
	}
		
	
}
