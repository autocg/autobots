package com.autobots.pages;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.dom4j.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
public class AutoPages
{

	 public static WebDriver driver;
	 //public int count =0; 
	 File htmlTemplateFile;
	String title,body,htmlString,StartTime;
	ExtentReports reports;
	ExtentTest logger;
	static	File ts;
	   
	   public AutoPages(WebDriver driver)
      {
		   this.driver = driver;
		  reports=new ExtentReports(System.getProperty("user.dir")+"\\Report\\ExtentReportResults.html",true);
			logger=reports.startTest("ExtentDemo");
	   }
	   
	   public boolean Visibility(String xPath)
		{
			try 
			{
				WebDriverWait wait = new WebDriverWait(driver,20);
			    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xPath)));
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.exit(0);
			}
			return true;
		}
	   

public void Click(String xPath)
     {  
	System.out.println(xPath);       
	if(Visibility(xPath))
	           driver.findElement(By.xpath(xPath)).click();
		captureScreenshot("img1.jpeg");
     }

public void SendValues(String value , String xPath)
{
	if(Visibility(xPath))
	   driver.findElement(By.xpath(xPath)).sendKeys(value);
		captureScreenshot("img.jpeg");
		logger.log(LogStatus.PASS,"Passed");
}

public void Clear(String xPath)
{
	if(Visibility(xPath))
		driver.findElement(By.xpath(xPath)).clear();
}

public void DropDown(String xPath, String value)
{
	if(Visibility(xPath))
	{
	Select City= new Select(driver.findElement(By.xpath(xPath)));
    City.selectByValue(value); 
	}
}

public void CheckBox(String xPath)
{
	if(Visibility(xPath))
	{ 
	List<WebElement> check = driver.findElements(By.xpath(xPath));
	 check.get(0).click();
	}
}

public String getXpath(Document document, String xmlXPath)
{
	
	//System.out.println(driver.findElement(By.id(document.selectSingleNode(xmlXPath).getText())).toString());
	return driver.findElement(By.xpath(document.selectSingleNode(xmlXPath).getText())).toString();

}

public String getXmlValue(Document document,String xml)
{
	return document.selectSingleNode(xml).getText();
}

public void travellerCount(String xPath,int n)
{
	
for(int i=1;i<n;i++)
      Click(xPath);

}
public String  getXmlPath(String Xml) 
{
	String s ="//goibibo/path/";
	return s.concat(Xml);
}

public String  getXmlData(String Data) 
{
	String s ="//goibibo/data/";
	return s.concat(Data);
}

public void initHtmlReport(int counter,long starttime, long endtime)
{
	
	htmlTemplateFile=new File("./Report/ReportTemplate.html");
	try
	{
		htmlString = FileUtils.readFileToString(htmlTemplateFile);
	}
	catch(IOException e)
	{
		System.out.println("Error in init html generator");
		e.printStackTrace();
	}
	
	
	title="Html Reports";
	body="Total Tests Run="+counter;
	htmlString=htmlString.replace("$title",title);
	htmlString=htmlString.replace("$body",body);
	htmlString=htmlString.replace("$starttime",starttime+"");
	htmlString=htmlString.replace("$endtime",endtime+"");
	htmlString=htmlString.replace("$table","<br>Testing my logic");
	//htmlString=htmlString.replace("$StartTime",StartTime);


	try
	{
		LocalDate rep=LocalDate.now();
		File htmlReport = new File("./Report/"+rep+".html");
		FileUtils.writeStringToFile(htmlReport,htmlString);
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}

public static void captureScreenshot( String screenshotName) {
	try
	{
		 ts=((TakesScreenshot)driver)
							.getScreenshotAs(OutputType.FILE);
		//String dest=""+screenshotName;
		File destination=new File("ScreenShot\\"+screenshotName);
		FileUtils.copyFile(ts, destination);
		System.out.println("Screenshot taken");
		
	}
	catch(Exception e)
	{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		 e.getMessage();
	}
}


public  void endTest()
{
	reports.endTest(logger);
	reports.flush();
}



}

